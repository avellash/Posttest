peserta = {
    9901 : {"nama" : "kim sujung", "negara" : "Korea", "status" : "tereliminasi"},
    9902 : {"nama" : "tomioka mai", "negara" : "Jepang", "status" : "debut"},
    9903 : {"nama" : "lingling", "negara" : "Malaysia", "status" : "tereliminasi"},
    9904 : {"nama" : "nam yuju", "negara" : "Korea", "status" : "tereliminasi"},
    9905 : {"nama" : "choi jungeun", "negara" : "Korea", "status" : "debut"},
    9906 : {"nama" : "fuko", "negara" : "Jepang", "status" : "tereliminasi"}
}
for key, value in peserta.items():
    print( "nomor peserta : ", key)
    for key_a, value_a in value.items():
        print (key_a, " : ", value_a)
    print("")

peserta[9901]["status"] = "debut"
print(peserta)