# Variabel Global
global_participants = []
global_scores = {}
global_max_challenges = 3

# Fungsi tanpa parameter: Menampilkan peserta beserta skor mereka
def show_scores():
    if global_scores:
        print("Skor peserta saat ini:")
        for participant, scores in global_scores.items():
            print(f"{participant}: {scores}")
    else:
        print("Tidak ada skor yang tersedia.")

# Fungsi dengan parameter: Menambahkan peserta
def add_participant(name):
    global global_participants, global_scores
    if name not in global_participants:
        global_participants.append(name)
        global_scores[name] = [0] * global_max_challenges  # Skor awal 0 untuk setiap tantangan
        print(f"{name} telah ditambahkan ke daftar peserta.")
    else:
        print(f"{name} sudah ada di daftar peserta.")

# Fungsi dengan parameter: Mengupdate skor peserta setelah tantangan
def update_scores(challenge_number, scores):
    global global_participants, global_scores
    if len(scores) != len(global_participants):
        print("Jumlah skor tidak sesuai dengan jumlah peserta.")
        return

    for i, participant in enumerate(global_participants):
        global_scores[participant][challenge_number] = scores[i]

# Prosedur: Menjalankan satu tantangan
def run_challenge(challenge_number):
    local_scores = []

    # Mengumpulkan skor secara acak (simulasi)
    print(f"\nTantangan {challenge_number + 1}:")
    for participant in global_participants:
        score = int(input(f"Masukkan skor untuk {participant} (0-100): "))
        local_scores.append(score)

    update_scores(challenge_number, local_scores)

# Prosedur: Mengeliminasi peserta dengan total skor terendah
def eliminate_lowest_scorer():
    global global_participants, global_scores
    total_scores = {p: sum(scores) for p, scores in global_scores.items()}
    lowest_scorer = min(total_scores, key=total_scores.get)

    print(f"{lowest_scorer} dieliminasi dengan total skor {total_scores[lowest_scorer]}.")
    global_participants.remove(lowest_scorer)
    del global_scores[lowest_scorer]

# Fungsi untuk memulai permainan
def start_game():
    for challenge in range(global_max_challenges):
        run_challenge(challenge)
        show_scores()
        eliminate_lowest_scorer()

    print("\n=== Permainan selesai! ===")
    if len(global_participants) == 1:
        print(f"{global_participants[0]} adalah pemenangnya!")
    else:
        print("Tidak ada pemenang.")

# Menjalankan program utama
def main():
    add_participant("Eve")
    add_participant("Frank")
    add_participant("Grace")
    add_participant("Henry")

    start_game()

# Panggil fungsi utama
main()
